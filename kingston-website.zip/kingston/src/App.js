import { useState, useEffect } from "react";

const products = [
  { id: 1, name: "VOID TEE", price: "$48", tag: "CORE", color: "BLK", bg: "linear-gradient(160deg, #111 0%, #1a3a2a 100%)" },
  { id: 2, name: "SILENT CARGO", price: "$120", tag: "NEW", color: "GRY", bg: "linear-gradient(160deg, #141414 0%, #1e1e1e 100%)" },
  { id: 3, name: "GHOST HOODIE", price: "$95", tag: "CORE", color: "BLK", bg: "linear-gradient(160deg, #0f1a14 0%, #162a20 100%)" },
  { id: 4, name: "ATLAS JACKET", price: "$180", tag: "LIMITED", color: "NVY", bg: "linear-gradient(160deg, #0a0f1a 0%, #111828 100%)" },
  { id: 5, name: "BLANK SHORTS", price: "$65", tag: "CORE", color: "WHT", bg: "linear-gradient(160deg, #181818 0%, #222 100%)" },
  { id: 6, name: "RECON PANTS", price: "$135", tag: "NEW", color: "GRN", bg: "linear-gradient(160deg, #0d1f18 0%, #1a3328 100%)" },
];

const KingstonLogo = ({ size = 40, showWordmark = true }) => (
  <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
    <svg width={size} height={size} viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="30" cy="30" r="29" fill="#080808" stroke="#ede9e322" strokeWidth="1"/>
      <g fill="#ede9e3">
        <rect x="14" y="12" width="5" height="36" rx="0.5"/>
        <rect x="11" y="12" width="11" height="2" rx="0.5"/>
        <rect x="11" y="46" width="11" height="2" rx="0.5"/>
        <path d="M19 30 L38 13 L44 13 L24 30.5Z" />
        <path d="M19 31 L44 47 L38 47 L19 32Z" />
        <path d="M30 29 L33 30.5 L30 32 L27 30.5Z" fill="#1d4a35"/>
      </g>
    </svg>
    {showWordmark && (
      <span style={{
        fontFamily: "'Bebas Neue', sans-serif",
        fontSize: "22px",
        letterSpacing: "0.22em",
        color: "#ede9e3",
        lineHeight: 1
      }}>
        KINGSTON
      </span>
    )}
  </div>
);

export default function App() {
  const [hoveredProduct, setHoveredProduct] = useState(null);
  const [scrolled, setScrolled] = useState(false);
  const [tickerIdx, setTickerIdx] = useState(0);
  const ticker = ["FREE SHIPPING OVER $150", "NEW DROP — ATLAS JACKET", "CLEAN. QUIET. UNCOMPROMISING.", "WEAR WHAT YOU FEEL"];

  useEffect(() => {
    const t = setInterval(() => setTickerIdx(i => (i + 1) % ticker.length), 3000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <div style={{ fontFamily: "sans-serif", background: "#080808", color: "#ede9e3", minHeight: "100vh", overflowX: "hidden" }}>
      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 2px; }
        ::-webkit-scrollbar-thumb { background: #1d4a35; }
        .bebas { font-family: 'Bebas Neue', sans-serif; }
        .mono { font-family: 'Space Mono', monospace; }
        .grain::after {
          content: '';
          position: fixed; inset: 0;
          pointer-events: none; z-index: 9999;
          opacity: 0.04;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23n)'/%3E%3C/svg%3E");
        }
        .ticker-fade { animation: tfade 0.4s ease; }
        @keyframes tfade { from { opacity:0; transform:translateY(5px); } to { opacity:1; transform:translateY(0); } }
        .reveal-wrap { overflow: hidden; display: block; }
        .reveal-inner { display: block; animation: revealUp 1s cubic-bezier(.16,1,.3,1) both; }
        @keyframes revealUp {
          from { transform: translateY(100%); opacity: 0; }
          to   { transform: translateY(0);    opacity: 1; }
        }
        .mq-wrap { overflow: hidden; white-space: nowrap; }
        .mq-track { display: inline-block; animation: mq 22s linear infinite; }
        @keyframes mq { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        .pcard { transition: all 0.35s cubic-bezier(.16,1,.3,1); cursor: pointer; }
        .pcard:hover { transform: translateY(-6px); }
        .btn-solid {
          background: #1d4a35; color: #ede9e3; border: none; cursor: pointer;
          font-family: 'Space Mono', monospace; letter-spacing: 0.16em; font-size: 11px;
          transition: background 0.25s, color 0.25s; padding: 14px 36px;
        }
        .btn-solid:hover { background: #ede9e3; color: #080808; }
        .btn-outline {
          background: transparent; color: #ede9e3; border: 1px solid #333; cursor: pointer;
          font-family: 'Space Mono', monospace; letter-spacing: 0.16em; font-size: 11px;
          transition: background 0.25s, color 0.25s, border-color 0.25s; padding: 14px 36px;
        }
        .btn-outline:hover { background: #ede9e3; color: #080808; border-color: #ede9e3; }
        .btn-ghost {
          background: rgba(29,74,53,0.15); color: #ede9e3; border: 1px solid #1d4a35;
          cursor: pointer; font-family: 'Space Mono', monospace; letter-spacing: 0.14em;
          font-size: 10px; transition: all 0.2s; padding: 11px 20px; width: 100%;
        }
        .btn-ghost:hover { background: #1d4a35; }
        .nlink {
          font-family: 'Space Mono', monospace; font-size: 10px; letter-spacing: 0.2em;
          cursor: pointer; color: #888; transition: color 0.2s; text-transform: uppercase;
        }
        .nlink:hover { color: #ede9e3; }
        .tag { font-family: 'Space Mono', monospace; font-size: 8px; letter-spacing: 0.18em; padding: 3px 8px; border: 1px solid; }
        .flink {
          font-family: 'Space Mono', monospace; font-size: 10px; color: #444;
          cursor: pointer; transition: color 0.2s; letter-spacing: 0.1em;
          display: block; margin-bottom: 10px;
        }
        .flink:hover { color: #ede9e3; }
        .stat-box { padding: 28px 22px; border: 1px solid #161616; background: #0d0d0d; transition: border-color 0.3s; }
        .stat-box:hover { border-color: #1d4a35; }
      `}</style>

      <div className="grain" />

      {/* TICKER */}
      <div style={{ background: "#0d0d0d", borderBottom: "1px solid #141414", padding: "9px 0", textAlign: "center" }}>
        <span className="mono ticker-fade" key={tickerIdx} style={{ fontSize: "9px", letterSpacing: "0.28em", color: "#555" }}>
          {ticker[tickerIdx]}
        </span>
      </div>

      {/* NAV */}
      <nav style={{
        position: "sticky", top: 0, zIndex: 100,
        background: scrolled ? "rgba(8,8,8,0.95)" : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled ? "1px solid #141414" : "1px solid transparent",
        transition: "all 0.4s", padding: "0 40px",
        display: "flex", alignItems: "center", justifyContent: "space-between", height: "68px"
      }}>
        <div style={{ display: "flex", gap: "32px" }}>
          {["Shop", "Lookbook"].map(n => <span key={n} className="nlink">{n}</span>)}
        </div>
        <div style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", cursor: "pointer" }}>
          <KingstonLogo size={38} showWordmark={true} />
        </div>
        <div style={{ display: "flex", gap: "32px", alignItems: "center" }}>
          {["About", "Drop"].map(n => <span key={n} className="nlink">{n}</span>)}
          <span className="mono" style={{ fontSize: "10px", letterSpacing: "0.15em", color: "#555", cursor: "pointer" }}>Bag (0)</span>
        </div>
      </nav>

      {/* HERO */}
      <section style={{
        minHeight: "94vh", display: "flex", flexDirection: "column",
        justifyContent: "flex-end", padding: "0 40px 72px",
        position: "relative", borderBottom: "1px solid #141414", overflow: "hidden"
      }}>
        <div style={{
          position: "absolute", top: "8%", right: "6%", width: "36vw", height: "72vh", maxWidth: "520px",
          background: "linear-gradient(135deg, #0e2419 0%, #0a1910 100%)",
          border: "1px solid #1d4a3533", zIndex: 0
        }} />
        <div style={{
          position: "absolute", top: "11%", right: "9%", width: "30vw", height: "66vh", maxWidth: "440px",
          border: "1px solid #1d4a3518", zIndex: 0
        }} />
        <div style={{
          position: "absolute", top: "50%", right: "6%", transform: "translateY(-50%)",
          width: "36vw", maxWidth: "520px",
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          zIndex: 1, gap: "16px"
        }}>
          <KingstonLogo size={120} showWordmark={false} />
          <span className="mono" style={{ fontSize: "9px", color: "#1d4a35", letterSpacing: "0.3em" }}>Kingston / Collection One</span>
        </div>
        <div style={{ position: "relative", zIndex: 2 }}>
          <span className="mono" style={{ fontSize: "10px", letterSpacing: "0.3em", color: "#1d4a35", display: "block", marginBottom: "20px" }}>
            SS25 — Clean Rebellion
          </span>
          {[
            { text: "KING", outline: false, delay: "0s" },
            { text: "OF YOUR", outline: true, delay: "0.12s" },
            { text: "OWN.", outline: false, delay: "0.24s" },
          ].map(({ text, outline, delay }) => (
            <span key={text} className="reveal-wrap" style={{ display: "block" }}>
              <span className="reveal-inner bebas" style={{
                fontSize: "clamp(72px, 13vw, 168px)", lineHeight: 0.88,
                animationDelay: delay,
                color: outline ? "transparent" : "#ede9e3",
                WebkitTextStroke: outline ? "1px #ede9e3" : "none",
                display: "block"
              }}>{text}</span>
            </span>
          ))}
          <div style={{ display: "flex", gap: "14px", marginTop: "48px", alignItems: "center", flexWrap: "wrap" }}>
            <button className="btn-solid">Shop Now</button>
            <button className="btn-outline">View Lookbook</button>
            <span className="mono" style={{ fontSize: "9px", color: "#333", letterSpacing: "0.2em", marginLeft: "8px" }}>↓ Scroll</span>
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div style={{ background: "#0b0b0b", borderBottom: "1px solid #141414", padding: "16px 0" }}>
        <div className="mq-wrap">
          <div className="mq-track mono" style={{ fontSize: "10px", letterSpacing: "0.28em" }}>
            {[...Array(2)].map((_, i) => (
              <span key={i}>
                {["Kingston", "·", "Clean Boy Streetwear", "·", "Wear What You Feel", "·", "No Hype Needed", "·", "SS25 Drop", "·", "Feel It Or Don't", "·", "Quiet Confidence", "·"].map((w, j) => (
                  <span key={`${i}-${j}`} style={{ marginRight: "28px", color: j % 2 === 1 ? "#1d4a35" : "#252525" }}>{w}</span>
                ))}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* PRODUCTS */}
      <section style={{ padding: "80px 40px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "40px" }}>
          <div>
            <span className="mono" style={{ fontSize: "9px", letterSpacing: "0.28em", color: "#1d4a35", display: "block", marginBottom: "10px" }}>Current Drop</span>
            <h2 className="bebas" style={{ fontSize: "clamp(40px, 5vw, 60px)", letterSpacing: "0.06em" }}>The Collection</h2>
          </div>
          <button className="btn-outline" style={{ padding: "10px 22px", fontSize: "9px" }}>View All</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(270px, 1fr))", gap: "2px" }}>
          {products.map((p) => (
            <div key={p.id} className="pcard"
              onMouseEnter={() => setHoveredProduct(p.id)}
              onMouseLeave={() => setHoveredProduct(null)}
              style={{ background: hoveredProduct === p.id ? "#111" : "#0d0d0d", border: "1px solid #141414", transition: "background 0.3s" }}
            >
              <div style={{ height: "320px", background: p.bg, position: "relative", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="80" height="80" viewBox="0 0 60 60" fill="none" style={{ opacity: 0.06 }}>
                  <g fill="#ede9e3">
                    <rect x="14" y="12" width="5" height="36" rx="0.5"/>
                    <rect x="11" y="12" width="11" height="2" rx="0.5"/>
                    <rect x="11" y="46" width="11" height="2" rx="0.5"/>
                    <path d="M19 30 L38 13 L44 13 L24 30.5Z" />
                    <path d="M19 31 L44 47 L38 47 L19 32Z" />
                  </g>
                </svg>
                <div style={{ position: "absolute", top: "14px", left: "14px" }}>
                  <span className="tag" style={{
                    color: p.tag === "LIMITED" ? "#b8963e" : p.tag === "NEW" ? "#1d4a35" : "#333",
                    borderColor: p.tag === "LIMITED" ? "#b8963e55" : p.tag === "NEW" ? "#1d4a3555" : "#222"
                  }}>{p.tag}</span>
                </div>
                <div style={{
                  position: "absolute", bottom: "14px", left: "14px", right: "14px",
                  opacity: hoveredProduct === p.id ? 1 : 0,
                  transform: hoveredProduct === p.id ? "translateY(0)" : "translateY(8px)",
                  transition: "all 0.3s cubic-bezier(.16,1,.3,1)"
                }}>
                  <button className="btn-ghost">Quick Add</button>
                </div>
              </div>
              <div style={{ padding: "18px 18px 22px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <span className="bebas" style={{ fontSize: "19px", letterSpacing: "0.08em" }}>{p.name}</span>
                  <span className="mono" style={{ fontSize: "12px", color: "#666" }}>{p.price}</span>
                </div>
                <span className="mono" style={{ fontSize: "9px", color: "#333", letterSpacing: "0.15em", display: "block", marginTop: "5px" }}>Color — {p.color}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* MANIFESTO */}
      <section style={{
        borderTop: "1px solid #141414", borderBottom: "1px solid #141414",
        background: "#070707", padding: "100px 40px",
        display: "grid", gridTemplateColumns: "1fr 1fr", gap: "80px", alignItems: "center"
      }}>
        <div>
          <span className="mono" style={{ fontSize: "9px", letterSpacing: "0.28em", color: "#1d4a35", display: "block", marginBottom: "20px" }}>The Kingston Way</span>
          <div style={{ marginBottom: "32px" }}>
            {[
              { text: "BUILT FOR", outline: false },
              { text: "THE ONES", outline: true },
              { text: "WHO FEEL.", outline: false },
            ].map(({ text, outline }) => (
              <div key={text} className="bebas" style={{
                fontSize: "clamp(38px, 5.5vw, 68px)", lineHeight: 0.92,
                color: outline ? "transparent" : "#ede9e3",
                WebkitTextStroke: outline ? "1px #ede9e3" : "none"
              }}>{text}</div>
            ))}
          </div>
          <p className="mono" style={{ fontSize: "11px", lineHeight: "2.1", color: "#555", maxWidth: "380px" }}>
            It doesn't matter what's in your wallet. If you feel it, you belong here. Kingston is for the quiet rebels — the ones who move clean and live on their own terms.
          </p>
          <button className="btn-outline" style={{ marginTop: "36px" }}>Our Story</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2px" }}>
          {[["∞", "Timeless Pieces"], ["01", "SS25 Season"], ["—", "Zero Compromise"], ["↑", "Always Evolving"]].map(([sym, label]) => (
            <div key={label} className="stat-box">
              <div className="bebas" style={{ fontSize: "38px", color: "#1d4a35", marginBottom: "12px" }}>{sym}</div>
              <p className="mono" style={{ fontSize: "9px", letterSpacing: "0.18em", color: "#444" }}>{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* EMAIL SIGNUP */}
      <section style={{ padding: "80px 40px", borderBottom: "1px solid #141414", textAlign: "center" }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: "24px" }}>
          <KingstonLogo size={52} showWordmark={false} />
        </div>
        <span className="mono" style={{ fontSize: "9px", letterSpacing: "0.28em", color: "#1d4a35", display: "block", marginBottom: "16px" }}>Stay In The Loop</span>
        <h3 className="bebas" style={{ fontSize: "clamp(36px, 5vw, 58px)", letterSpacing: "0.06em", marginBottom: "12px" }}>Get Early Access To Drops</h3>
        <p className="mono" style={{ fontSize: "11px", color: "#444", marginBottom: "36px", letterSpacing: "0.1em" }}>No spam. Just new drops before anyone else.</p>
        <div style={{ display: "flex", gap: "0", maxWidth: "460px", margin: "0 auto" }}>
          <input placeholder="Your Email" style={{
            flex: 1, background: "#0d0d0d", border: "1px solid #1e1e1e",
            borderRight: "none", color: "#ede9e3", padding: "14px 18px",
            fontFamily: "'Space Mono', monospace", fontSize: "10px",
            letterSpacing: "0.15em", outline: "none"
          }} />
          <button className="btn-solid" style={{ padding: "14px 28px", flexShrink: 0 }}>Join</button>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ padding: "60px 40px 36px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: "40px", marginBottom: "60px" }}>
          <div>
            <KingstonLogo size={44} showWordmark={true} />
            <p className="mono" style={{ fontSize: "9px", color: "#333", letterSpacing: "0.18em", lineHeight: "1.8", marginTop: "14px" }}>
              Clean. Quiet.<br />Uncompromising.
            </p>
          </div>
          {[
            ["Shop", ["New Arrivals", "Tops", "Bottoms", "Outerwear", "Accessories"]],
            ["Info", ["About Us", "Sizing Guide", "Shipping", "Returns"]],
            ["Connect", ["Instagram", "Newsletter", "Contact", "Press"]],
          ].map(([title, links]) => (
            <div key={title}>
              <p className="mono" style={{ fontSize: "9px", letterSpacing: "0.24em", color: "#1d4a35", marginBottom: "18px" }}>{title}</p>
              {links.map(l => <span key={l} className="flink">{l}</span>)}
            </div>
          ))}
        </div>
        <div style={{ borderTop: "1px solid #161616", paddingTop: "24px", display: "flex", justifyContent: "space-between" }}>
          <span className="mono" style={{ fontSize: "9px", color: "#252525", letterSpacing: "0.12em" }}>© 2025 Kingston. All Rights Reserved.</span>
          <span className="mono" style={{ fontSize: "9px", color: "#252525", letterSpacing: "0.12em" }}>SS25 — Clean Rebellion</span>
        </div>
      </footer>
    </div>
  );
}
