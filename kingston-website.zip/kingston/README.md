# Kingston — SS25 Clean Rebellion

Your e-commerce streetwear website, ready to deploy.

## 🚀 Deploy in 3 Steps

### Step 1 — Install Node.js
Download from: https://nodejs.org (choose the LTS version)

### Step 2 — Upload to GitHub
1. Go to github.com → New Repository → name it "kingston"
2. Upload all these files into the repo

### Step 3 — Deploy on Vercel
1. Go to vercel.com
2. Sign in with GitHub
3. Click "Add New Project" → select your "kingston" repo
4. Click Deploy ✅

Your site will be live at: https://kingston.vercel.app

---

## 📁 File Structure
```
kingston/
├── public/
│   └── index.html       ← Page shell & fonts
├── src/
│   ├── index.js         ← React entry point
│   └── App.js           ← Your full website
├── package.json         ← Project config
└── README.md            ← This file
```

## ✏️ Customizing Your Site
- **Products**: Edit the `products` array in `src/App.js`
- **Colors**: Search for `#1d4a35` to change the green accent
- **Copy**: Search for "KING OF YOUR OWN" to edit hero text
- **Logo**: Replace the SVG in `KingstonLogo` with your real logo

---
Built for Kingston © 2025
